package mk.ukim.finki.fooddeliverybackend.dto.domain;

public record LoginUserResponseDto(
        String token
) {
}

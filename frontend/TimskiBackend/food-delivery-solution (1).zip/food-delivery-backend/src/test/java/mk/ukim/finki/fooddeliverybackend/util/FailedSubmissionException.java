package mk.ukim.finki.fooddeliverybackend.util;

public class FailedSubmissionException extends RuntimeException {
}
